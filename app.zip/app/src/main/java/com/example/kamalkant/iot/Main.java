package com.example.kamalkant.iot;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;

public class Main extends AppCompatActivity {

    private WebView mWebView;
    private Button button1;
    private Button button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mWebView = (WebView)findViewById(R.id.activity_main_webview);
        mWebView.setBackgroundResource(R.drawable.finalicon);
        mWebView.setBackgroundColor(0x00000000);

        button1=(Button)findViewById(R.id.button1);
        button1.setOnClickListener(
                new View.OnClickListener(){
                    public void onClick(View v){
                        WebSettings webSettings = mWebView.getSettings();
                        webSettings.setJavaScriptEnabled(true);
                        mWebView.loadUrl("http://192.168.0.112:3000");
                        mWebView.setWebViewClient(new WebViewClient());
                    }
                }
        );

        button2=(Button)findViewById(R.id.button2);
        button2.setOnClickListener(
                new View.OnClickListener() {
                    public void onClick(View v) {
                        WebSettings webSettings = mWebView.getSettings();
                        webSettings.setJavaScriptEnabled(true);
                        mWebView.loadUrl("http://192.168.173.18:3000");
                        mWebView.setWebViewClient(new WebViewClient());
                    }
                }
        );

    }
    @Override
    public void onBackPressed(){
        if(mWebView.canGoBack()){
            mWebView.goBack();
        } else{
            super.onBackPressed();
        }
    }
}
